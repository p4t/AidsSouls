CREATE DATABASE IF NOT EXISTS `aids`;

USE `aids`;

DROP TABLE IF EXISTS `boss`;

CREATE TABLE `boss` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `dice` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

INSERT INTO `boss` VALUES("1","1","Ohne Schild");
INSERT INTO `boss` VALUES("2","2","Symbol of AIIIIIIIIDS");
INSERT INTO `boss` VALUES("3","3","Ohne Rüstung");
INSERT INTO `boss` VALUES("4","4","Fatroll");
INSERT INTO `boss` VALUES("5","5","Zufällige Waffe");
INSERT INTO `boss` VALUES("6","6","Waffe linke Hand");
INSERT INTO `boss` VALUES("7","7","Nur R2");
INSERT INTO `boss` VALUES("8","8","Lumbe");
INSERT INTO `boss` VALUES("9","9","Crap Waffe");
INSERT INTO `boss` VALUES("10","10","Ohne Ringe");
INSERT INTO `boss` VALUES("11","11","Ohne Alles");
INSERT INTO `boss` VALUES("12","12","Crap Ringe");
INSERT INTO `boss` VALUES("13","13","Normal");
INSERT INTO `boss` VALUES("14","14","Normal");
INSERT INTO `boss` VALUES("15","15","Flask Würfeln");



DROP TABLE IF EXISTS `ds3`;

CREATE TABLE `ds3` (
  `ID` tinyint(10) NOT NULL AUTO_INCREMENT,
  `mobDice` tinyint(10) DEFAULT NULL,
  `mobName` varchar(255) NOT NULL,
  `bossDice` tinyint(10) DEFAULT NULL,
  `bossName` varchar(255) NOT NULL,
  `weaponDice` tinyint(10) DEFAULT NULL,
  `weaponName` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

INSERT INTO `ds3` VALUES("1","1","Ohne Schild","1","Ohne Schild","1","Club");
INSERT INTO `ds3` VALUES("2","2","Ohne Flask","2","Ohne Flask","2","Rapier");
INSERT INTO `ds3` VALUES("3","3","Ohne Rüstung","3","Ohne Rüstung","3","Deep Battle Axe");
INSERT INTO `ds3` VALUES("4","4","Fatroll","4","Fatroll","4","Lucerne");
INSERT INTO `ds3` VALUES("5","5","Parry/Lumbe","5","Zufällige Waffe","5","Greataxe");
INSERT INTO `ds3` VALUES("6","6","Waffe linke Hand","6","Waffe linke Hand","6","Handaxe");
INSERT INTO `ds3` VALUES("7","7","Nur RT","7","Nur RT","7","Broadsword");
INSERT INTO `ds3` VALUES("8","8","Invade","8","Lumbe","8","Brigand Axe");
INSERT INTO `ds3` VALUES("9","9","Crap Waffe","9","Normal","9","Partizan");
INSERT INTO `ds3` VALUES("10","10","Ohne Ringe","10","Ohne Ringe","10","Zweihänder");
INSERT INTO `ds3` VALUES("11","11","Ohne Alles","11","Ohne Alles","11","Executioner\'s Greatsword");
INSERT INTO `ds3` VALUES("12","12","Crap Ringe","12","Crap Ringe","12","Barbed Straightsword");
INSERT INTO `ds3` VALUES("13","13","No Hit Run",NULL,"","13","DarkSword");
INSERT INTO `ds3` VALUES("14","14","Kill on Sight",NULL,"","14","Astora Greatsword");
INSERT INTO `ds3` VALUES("15","15","No Dodge/Run",NULL,"","15","Butcher\'S Knife");
INSERT INTO `ds3` VALUES("16","16","Normal",NULL,"","16","Drang Hammers");
INSERT INTO `ds3` VALUES("17","17","Normal",NULL,"","17","Astor Spear");
INSERT INTO `ds3` VALUES("18","18","Zufällige Waffe",NULL,"","18","Whip");
INSERT INTO `ds3` VALUES("19","19","Zufällige Waffe",NULL,"","19","Crow Talons");
INSERT INTO `ds3` VALUES("20","20","Zufällige Waffe",NULL,"","20","Iritrill Straight Sword");



DROP TABLE IF EXISTS `kills`;

CREATE TABLE `kills` (
  `ID` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `joker` int(10) NOT NULL,
  `spent` int(10) NOT NULL,
  `bossNames` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `kills` VALUES("1","Biber","0","0","0");
INSERT INTO `kills` VALUES("2","Katz","2","2","Iudex Gundyr\nAbyss Watchers");
INSERT INTO `kills` VALUES("3","Pat","10","9","Vordt of the Boreal Valley\nCrystal Sage\nCurse-Rotted Greatwood\nDeacons of the Deep\nHigh Lord Wolnir\nOld Demon King\nYhorm The Giant\nPontiff Sulyvahn\nAldrich, Devourer of Gods\nDancer");
INSERT INTO `kills` VALUES("4","Coop","3","3","Crystal Sage\nYhorm the Giant\nPontiff Sulyvahn");



DROP TABLE IF EXISTS `mobs`;

CREATE TABLE `mobs` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `dice` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

INSERT INTO `mobs` VALUES("1","1","Ohne Schild");
INSERT INTO `mobs` VALUES("2","2","Ohne Flask");
INSERT INTO `mobs` VALUES("3","3","Ohne Rüstung");
INSERT INTO `mobs` VALUES("4","4","Fatroll");
INSERT INTO `mobs` VALUES("5","5","Zufällige Waffe");
INSERT INTO `mobs` VALUES("6","6","Waffe linke Hand");
INSERT INTO `mobs` VALUES("7","7","Nur R2");
INSERT INTO `mobs` VALUES("8","8","Lumbe");
INSERT INTO `mobs` VALUES("9","9","Crap Waffe");
INSERT INTO `mobs` VALUES("10","10","Ohne Ringe");
INSERT INTO `mobs` VALUES("11","11","Ohne Alles");
INSERT INTO `mobs` VALUES("12","12","Crap Ringe");
INSERT INTO `mobs` VALUES("13","13","Normal");
INSERT INTO `mobs` VALUES("14","14","Normal");
INSERT INTO `mobs` VALUES("15","15","Flask Würfeln");
INSERT INTO `mobs` VALUES("16","16","No Dodge/Run");
INSERT INTO `mobs` VALUES("17","17","Invert Controls");
INSERT INTO `mobs` VALUES("18","18","Kill on Sight");
INSERT INTO `mobs` VALUES("19","19","Parry");
INSERT INTO `mobs` VALUES("20","20","Invade");
INSERT INTO `mobs` VALUES("21","21","Symbol of AIIIIIIIIDS");



DROP TABLE IF EXISTS `rolls`;

CREATE TABLE `rolls` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `IP` varchar(255) NOT NULL,
  `mobs` varchar(255) NOT NULL,
  `boss` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `rolls` VALUES("1","2018-04-02 21:37:14","95.90.230.5","Ohne Flask","Ohne Rüstung");
INSERT INTO `rolls` VALUES("2","2018-04-02 21:38:44","95.90.230.5","Ohne Ringe","Nur R2");
INSERT INTO `rolls` VALUES("3","2018-04-02 21:39:06","95.90.230.5","Drang Hammers","Crap Waffe");
INSERT INTO `rolls` VALUES("4","2018-04-02 21:41:49","2a02:810b:c540:5fb4:112b:9a25:19a5:eba6","Crap Ringe","Crap Ringe");



DROP TABLE IF EXISTS `todo`;

CREATE TABLE `todo` (
  `ID` int(10) NOT NULL,
  `todoText` text NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `todo` VALUES("1","- 1 Schatztruhe Dungeon Frösche\n- Loot ithryll valley bei pointiff\n- Speer Typ bei Skelette, Loot bei Krabbe\n- bonfire dingens bei demon bonfire\n- Drache Loot\n- Ohne Backstab/Riposte/Plunge?\n- No Hit Run\n- Hunde unten beim Covenant\n- Dusk Crown Ring\n- Magic Clutch Ring\n- Lightning Clutch Ring\n- Fire Clutch Ring\n- Dark Clutch Ring\n- Symbol of Aids, Carthus Bloodring\n- Calamity Ring\n- Symbol of Aids");



DROP TABLE IF EXISTS `weapons`;

CREATE TABLE `weapons` (
  `ID` int(10) NOT NULL AUTO_INCREMENT,
  `dice` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

INSERT INTO `weapons` VALUES("1","1","Pickaxe");
INSERT INTO `weapons` VALUES("2","2","Rapier");
INSERT INTO `weapons` VALUES("3","3","Black Knight sword");
INSERT INTO `weapons` VALUES("4","4","Great Club");
INSERT INTO `weapons` VALUES("5","5","Greataxe");
INSERT INTO `weapons` VALUES("6","6","Handaxe");
INSERT INTO `weapons` VALUES("7","7","Rotten Spear");
INSERT INTO `weapons` VALUES("8","8","Brigand Axe");
INSERT INTO `weapons` VALUES("9","9","Partizan");
INSERT INTO `weapons` VALUES("10","10","Soldering Iron");
INSERT INTO `weapons` VALUES("11","11","Executioner\'s Greatsword");
INSERT INTO `weapons` VALUES("12","12","Barbed Straight Sword");
INSERT INTO `weapons` VALUES("13","13","Dark Sword");
INSERT INTO `weapons` VALUES("14","14","Astora Greatsword");
INSERT INTO `weapons` VALUES("15","15","Butcher Knife");
INSERT INTO `weapons` VALUES("16","16","Drang Hammers");
INSERT INTO `weapons` VALUES("17","17","Arstor\'s Spear");
INSERT INTO `weapons` VALUES("18","18","Whip");
INSERT INTO `weapons` VALUES("19","19","Crow Talons");
INSERT INTO `weapons` VALUES("20","20","Yorshka\'s Spear");
